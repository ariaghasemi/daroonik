import { cache } from "react";
import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { brands, categories, messages, orders, posts, products, reviews } from "@/db/schema";
import { BRANDS, CATEGORIES, PRODUCTS, REVIEWS, type SeedProduct } from "@/data/catalog";
import { POSTS, type SeedPost } from "@/data/posts";

export type Product = SeedProduct & { id: number };
export type Category = (typeof CATEGORIES)[number];
export type Brand = (typeof BRANDS)[number];
export type Post = SeedPost;
export type Review = {
  author: string;
  rating: number;
  title: string;
  body: string;
  pros: string[];
  cons: string[];
  verified: boolean;
  productSlug: string;
};

let seedPromise: Promise<void> | null = null;

async function seed() {
  await db.transaction(async (tx) => {
    const [{ count }] = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(products);
    if (Number(count) > 0) return;

    await tx.insert(brands).values(BRANDS).onConflictDoNothing();
    await tx.insert(categories).values(CATEGORIES).onConflictDoNothing();
    await tx
      .insert(products)
      .values(
        PRODUCTS.map((p) => ({
          slug: p.slug,
          name: p.name,
          brandSlug: p.brandSlug,
          categorySlug: p.categorySlug,
          rootSlug: p.rootSlug,
          price: p.price,
          oldPrice: p.oldPrice ?? null,
          rating: p.rating,
          reviewCount: p.reviewCount,
          sold: p.sold,
          stock: p.stock,
          image: p.image,
          shortDesc: p.shortDesc,
          description: p.description,
          specs: p.specs,
          variants: p.variants,
          usage: p.usage,
          warning: p.warning,
          faq: p.faq,
          isNew: p.isNew,
          isBestseller: p.isBestseller,
          isFeatured: p.isFeatured,
          tags: p.tags,
        })),
      )
      .onConflictDoNothing();
    await tx.insert(reviews).values(REVIEWS).onConflictDoNothing();
    await tx.insert(posts).values(POSTS).onConflictDoNothing();
  });
}

export async function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = seed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

/* ------------------------- read helpers (DB first, static fallback) ------------------------- */

export const getProducts = cache(async (): Promise<Product[]> => {
  try {
    await ensureSeeded();
    const rows = await db.select().from(products).orderBy(asc(products.id));
    if (!rows.length) throw new Error("empty");
    return rows.map((r) => ({
      ...r,
      oldPrice: r.oldPrice ?? undefined,
      description: r.description ?? [],
      specs: r.specs ?? [],
      variants: r.variants ?? [],
      faq: r.faq ?? [],
      tags: r.tags ?? [],
    })) as Product[];
  } catch {
    return PRODUCTS.map((p, i) => ({ ...p, id: i + 1 }));
  }
});

export const getCategories = cache(async (): Promise<Category[]> => {
  try {
    await ensureSeeded();
    const rows = await db.select().from(categories).orderBy(asc(categories.sort));
    if (!rows.length) throw new Error("empty");
    return rows as Category[];
  } catch {
    return CATEGORIES;
  }
});

export const getBrands = cache(async (): Promise<Brand[]> => {
  try {
    await ensureSeeded();
    const rows = await db.select().from(brands).orderBy(asc(brands.id));
    if (!rows.length) throw new Error("empty");
    return rows as Brand[];
  } catch {
    return BRANDS;
  }
});

export const getPosts = cache(async (): Promise<Post[]> => {
  try {
    await ensureSeeded();
    const rows = await db.select().from(posts).orderBy(asc(posts.id));
    if (!rows.length) throw new Error("empty");
    return rows as unknown as Post[];
  } catch {
    return POSTS;
  }
});

export const getReviews = cache(async (productSlug: string): Promise<Review[]> => {
  try {
    await ensureSeeded();
    const rows = await db.select().from(reviews).where(eq(reviews.productSlug, productSlug));
    if (!rows.length) throw new Error("empty");
    return rows.map((r) => ({
      author: r.author,
      rating: r.rating,
      title: r.title,
      body: r.body,
      pros: r.pros ?? [],
      cons: r.cons ?? [],
      verified: r.verified,
      productSlug: r.productSlug,
    }));
  } catch {
    return REVIEWS.filter((r) => r.productSlug === productSlug);
  }
});

/* ------------------------- derived selectors ------------------------- */

export async function getCategoryTree() {
  const cats = await getCategories();
  const roots = cats.filter((c) => !c.parentSlug);
  return roots.map((root) => ({
    ...root,
    children: cats.filter((c) => c.parentSlug === root.slug),
  }));
}

export async function findCategory(slug: string) {
  const cats = await getCategories();
  return cats.find((c) => c.slug === slug) ?? null;
}

export async function getProductBySlug(slug: string) {
  const all = await getProducts();
  return all.find((p) => p.slug === slug) ?? null;
}

export async function getPostBySlug(slug: string) {
  const all = await getPosts();
  return all.find((p) => p.slug === slug) ?? null;
}

export type SortKey = "popular" | "newest" | "cheap" | "expensive" | "rating" | "discount";

export type FilterOptions = {
  root?: string;
  category?: string;
  brands?: string[];
  min?: number;
  max?: number;
  rating?: number;
  onlyAvailable?: boolean;
  onlyDiscount?: boolean;
  query?: string;
  sort?: SortKey;
};

export function applyFilters(list: Product[], o: FilterOptions): Product[] {
  let out = [...list];
  if (o.root) out = out.filter((p) => p.rootSlug === o.root);
  if (o.category) out = out.filter((p) => p.categorySlug === o.category);
  if (o.brands?.length) out = out.filter((p) => o.brands!.includes(p.brandSlug));
  if (o.min != null) out = out.filter((p) => p.price >= o.min!);
  if (o.max != null) out = out.filter((p) => p.price <= o.max!);
  if (o.rating) out = out.filter((p) => p.rating >= o.rating!);
  if (o.onlyAvailable) out = out.filter((p) => p.stock > 0);
  if (o.onlyDiscount) out = out.filter((p) => !!p.oldPrice && p.oldPrice > p.price);
  if (o.query) {
    const q = o.query.trim();
    if (q) out = out.filter((p) => `${p.name} ${p.shortDesc} ${p.brandSlug}`.includes(q));
  }
  switch (o.sort) {
    case "newest":
      out.sort((a, b) => Number(b.isNew) - Number(a.isNew) || b.id - a.id);
      break;
    case "cheap":
      out.sort((a, b) => a.price - b.price);
      break;
    case "expensive":
      out.sort((a, b) => b.price - a.price);
      break;
    case "rating":
      out.sort((a, b) => b.rating - a.rating);
      break;
    case "discount":
      out.sort(
        (a, b) =>
          (b.oldPrice ? (b.oldPrice - b.price) / b.oldPrice : 0) -
          (a.oldPrice ? (a.oldPrice - a.price) / a.oldPrice : 0),
      );
      break;
    default:
      out.sort((a, b) => b.sold - a.sold);
  }
  return out;
}

export async function searchEverything(q: string) {
  const term = q.trim();
  const [allProducts, cats, brandList, postList] = await Promise.all([
    getProducts(),
    getCategories(),
    getBrands(),
    getPosts(),
  ]);
  if (!term) return { products: [], categories: [], brands: [], posts: [] };
  return {
    products: allProducts.filter((p) => `${p.name} ${p.shortDesc}`.includes(term)).slice(0, 12),
    categories: cats.filter((c) => c.title.includes(term)).slice(0, 6),
    brands: brandList
      .filter((b) => b.name.includes(term) || b.nameEn.toLowerCase().includes(term.toLowerCase()))
      .slice(0, 6),
    posts: postList.filter((p) => `${p.title} ${p.excerpt}`.includes(term)).slice(0, 5),
  };
}

/* ------------------------- writes ------------------------- */

export type NewOrder = typeof orders.$inferInsert;

export async function createOrder(input: Omit<NewOrder, "id" | "code" | "createdAt">) {
  const code = `DRN-${Math.floor(100000 + Math.random() * 899999)}`;
  try {
    const [row] = await db.insert(orders).values({ ...input, code }).returning();
    return row;
  } catch {
    return { ...input, code, id: 0, createdAt: new Date(), status: "در حال پردازش" } as typeof orders.$inferSelect;
  }
}

export async function listOrders() {
  try {
    await ensureSeeded();
    return await db.select().from(orders).orderBy(asc(orders.id));
  } catch {
    return [];
  }
}

export async function getOrderByCode(code: string) {
  try {
    const rows = await db.select().from(orders).where(eq(orders.code, code));
    return rows[0] ?? null;
  } catch {
    return null;
  }
}

export async function saveMessage(input: typeof messages.$inferInsert) {
  try {
    await db.insert(messages).values(input);
    return true;
  } catch {
    return false;
  }
}
