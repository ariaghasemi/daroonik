import type { Metadata } from "next";
import { ShopView, type SP } from "@/components/shop-view";
import { getProducts } from "@/lib/store";

export const revalidate = 3600;

export const metadata: Metadata = {
  title: "پرفروش‌ترین محصولات",
  description: "پرفروش‌ترین محصولات داروخانه آنلاین دارونیک بر اساس خرید مشتریان؛ انتخابی مطمئن برای خرید آنلاین.",
  alternates: { canonical: "/bestsellers" },
};

export default async function BestsellersPage({ searchParams }: { searchParams: Promise<SP> }) {
  const [sp, products] = await Promise.all([searchParams, getProducts()]);
  return (
    <ShopView
      title="پرفروش‌ترین محصولات"
      description="این فهرست بر اساس تعداد فروش محصولات در فروشگاه مرتب شده است؛ اگر در انتخاب تردید دارید، از این صفحه شروع کنید."
      crumbs={[{ title: "پرفروش‌ترین‌ها" }]}
      products={products.filter((p) => p.isBestseller || p.sold > 700)}
      searchParams={{ ...sp, sort: sp.sort ?? "popular" }}
      basePath="/bestsellers"
    />
  );
}
