import Link from "next/link";
import type { Metadata } from "next";
import { ShopView, type SP } from "@/components/shop-view";
import { getProducts, searchEverything } from "@/lib/store";
import { toFa } from "@/lib/utils";

export const metadata: Metadata = {
  title: "جستجوی محصولات",
  description: "جستجو در میان محصولات، برندها، دسته‌بندی‌ها و مقالات مجله سلامت دارونیک.",
  robots: { index: false, follow: true },
};

export default async function SearchPage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const q = (Array.isArray(sp.q) ? sp.q[0] : sp.q) ?? "";
  const [products, extra] = await Promise.all([getProducts(), searchEverything(q)]);
  const scoped = q ? products.filter((p) => `${p.name} ${p.shortDesc} ${p.brandSlug}`.includes(q)) : [];

  return (
    <>
      {q && (extra.categories.length > 0 || extra.brands.length > 0 || extra.posts.length > 0) && (
        <div className="container-x pt-4">
          <div className="card flex flex-wrap items-center gap-2 p-3">
            <span className="text-[12px] font-bold text-ink-500">نتایج مرتبط:</span>
            {extra.categories.map((c) => (
              <Link key={c.slug} href={`/category/${c.parentSlug ? c.parentSlug + "/" : ""}${c.slug}`} className="chip">
                دسته: {c.title}
              </Link>
            ))}
            {extra.brands.map((b) => (
              <Link key={b.slug} href={`/brand/${b.slug}`} className="chip">
                برند: {b.name}
              </Link>
            ))}
            {extra.posts.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="chip">
                مقاله: {p.title}
              </Link>
            ))}
          </div>
        </div>
      )}
      <ShopView
        title={q ? `نتایج جستجو برای «${q}»` : "جستجو در فروشگاه"}
        description={
          q
            ? `${toFa(scoped.length)} محصول مرتبط با عبارت «${q}» پیدا شد. می‌توانید نتایج را با فیلترهای کناری محدودتر کنید.`
            : "برای شروع، عبارت موردنظر خود را در نوار جستجوی بالای صفحه وارد کنید؛ مثلاً «مولتی ویتامین»، «ضد آفتاب» یا «فشارسنج»."
        }
        crumbs={[{ title: "جستجو" }]}
        products={scoped}
        searchParams={{ ...sp, q: undefined }}
        basePath={`/search?q=${encodeURIComponent(q)}`}
      />
    </>
  );
}
