import { NextResponse } from "next/server";
import { searchEverything } from "@/lib/store";

export async function GET(request: Request) {
  const q = new URL(request.url).searchParams.get("q") ?? "";
  const result = await searchEverything(q);
  return NextResponse.json({
    products: result.products.map((p) => ({ slug: p.slug, name: p.name, image: p.image, price: p.price })),
    categories: result.categories.map((c) => ({ slug: c.slug, title: c.title, parentSlug: c.parentSlug })),
    brands: result.brands.map((b) => ({ slug: b.slug, name: b.name })),
    posts: result.posts.map((p) => ({ slug: p.slug, title: p.title })),
  });
}
